#ifndef _WPROGRAM_H
#define _WPROGRAM_H

#define ARDUINO 100
#include "Arduino.h"
#include <string>
#define __FlashStringHelper char
#include "Print.h"
#define boolean bool
#define __builtin_bswap16(x) ( ((x)<<8) | ((x)>>8) )
#endif
