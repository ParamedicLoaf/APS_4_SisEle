#ifndef MAIN_H
#define MAIN_H
#include "mbed.h"

void muda();

#endif